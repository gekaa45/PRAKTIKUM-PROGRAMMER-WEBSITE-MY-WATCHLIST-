<?php
include 'db.php';
$id = $_GET['id'];
$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM movies WHERE id_movie = '$id'"));

if(isset($_POST['update'])){
    $judul = $_POST['judul'];
    $genre = $_POST['genre'];
    $rating = $_POST['rating'];
    $desc = $_POST['desc'];
    
    // Cek jika ganti poster
    if($_FILES['poster']['name'] != ""){
        $poster = $_FILES['poster']['name'];
        move_uploaded_file($_FILES['poster']['tmp_name'], "uploads/".$poster);
    } else {
        $poster = $row['poster']; // pakai poster lama
    }

    mysqli_query($conn, "UPDATE movies SET judul_film='$judul', genre='$genre', rating='$rating', poster='$poster', deskripsi='$desc' WHERE id_movie='$id'");
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Diary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#141414; color:white;}</style>
</head>
<body>
<div class="container mt-5">
    <div class="card bg-dark text-white p-4 mx-auto border-secondary" style="max-width: 500px;">
        <h4 class="text-center mb-4">Edit Catatan Film</h4>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Judul Film</label>
                <input type="text" name="judul" class="form-control bg-secondary text-white border-0" value="<?= $row['judul_film']; ?>" required>
            </div>
            <div class="row mb-3">
                <div class="col"><label>Genre</label><input type="text" name="genre" class="form-control bg-secondary text-white border-0" value="<?= $row['genre']; 
                ?>"></div>
                <div class="col"><label>Rating</label><input type="number" step="0.1" name="rating" class="form-control bg-secondary text-white border-0" 
                value="<?= $row['rating']; ?>"></div>
            </div>
            <div class="mb-3">
                <label>Ganti Poster (Biarkan kosong jika tidak diubah)</label>
                <input type="file" name="poster" class="form-control bg-secondary text-white border-0">
            </div>
            <div class="mb-3">
                <label>Kenapa pengen nonton ini?</label>
                <textarea name="desc" class="form-control bg-secondary text-white border-0" rows="3"><?= $row['deskripsi']; ?></textarea>
            </div>
            <button type="submit" name="update" class="btn btn-info w-100 fw-bold">UPDATE CATATAN</button>
            <a href="index.php" class="btn btn-link text-secondary w-100 mt-2 text-decoration-none">Batal</a>
        </form>
    </div>
</div>
</body>
</html>