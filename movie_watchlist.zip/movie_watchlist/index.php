<?php 
include 'db.php'; 

// Memanggil file pendukung secara manual 
if (file_exists('Media.php') && file_exists('MovieLogic.php')) {
    require_once 'Media.php'; 
    require_once 'MovieLogic.php'; 
    
    $movieHelper = new \App\MovieLogic("Sistem Watchlist");
    $waktuSekarang = $movieHelper->tampilkanWaktu(); 
} else {
    $waktuSekarang = date('d-m-Y H:i');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Watchlist🍿</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body { background-color: #141414; color: white; font-family: 'Inter', sans-serif; }
        .navbar { background-color: rgba(0,0,0,0.9); border-bottom: 2px solid #e50914; }
        .movie-card { 
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); 
            border: none; background: #1f1f1f; border-radius: 15px; 
            overflow: hidden; box-shadow: 0 10px 20px rgba(0,0,0,0.5);
        }
        .movie-card:hover { 
            transform: translateY(-12px); 
            box-shadow: 0 15px 30px rgba(229, 9, 20, 0.4); 
        }
        .card-img-top { aspect-ratio: 2/3; object-fit: cover; }
        .btn-add { background-color: #e50914; color: white; font-weight: bold; border-radius: 50px; }
        .btn-add:hover { background-color: #b20710; color: white; }
        .card-title { font-size: 1.1rem; text-shadow: 1px 1px 3px rgba(0,0,0,0.8); font-weight: bold; }
        .swal2-popup { border-radius: 20px !important; border: 1px solid #333 !important; background-color: #1f1f1f !important; color: white !important; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark px-4 py-3 sticky-top">
    <div class="container d-flex justify-content-between align-items-center">
        <a class="navbar-brand fw-bold fs-3" href="index.php">MY WATCHLIST</a>
        <a href="tambah.php" class="btn btn-add px-4 shadow"><i class="fas fa-plus-circle me-2"></i>Tambah Film</a>
    </div>
</nav>

<div class="container mt-5 mb-5">
    <p class="text-end text-secondary">Sesi Aktif: <?= $waktuSekarang; ?></p>

    <div class="row row-cols-2 row-cols-md-4 row-cols-lg-5 g-4">
        <?php
        // Menggunakan Array dan Perulangan (Poin d & f)
        $query = mysqli_query($conn, "SELECT * FROM movies ORDER BY id_movie DESC");
        while($row = mysqli_fetch_assoc($query)):
            // Menggunakan Percabangan (Poin d)
            $opacity = ($row['status'] == 'Selesai') ? 'opacity-50' : '';
            $badge = ($row['status'] == 'Selesai') ? '<span class="badge bg-success position-absolute m-2 shadow" style="z-index:1">Selesai</span>' : '';
        ?>
        <div class="col">
            <div class="card movie-card h-100 <?= $opacity; ?>" style="position: relative;">
                <?= $badge; ?>
                <a href="detail.php?id=<?= $row['id_movie']; ?>">
                    <img src="uploads/<?= $row['poster']; ?>" class="card-img-top" alt="Poster">
                </a>
                <div class="card-body p-3">
                    <h6 class="card-title text-white text-truncate mb-1"><?= $row['judul_film']; ?></h6>
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <small class="text-warning fw-bold"><i class="fas fa-star me-1"></i><?= $row['rating']; ?></small>
                        <div class="d-flex align-items-center gap-2">
                            <a href="update_status.php?id=<?= $row['id_movie']; ?>&status=<?= $row['status']; 
                            ?>" class="text-success text-decoration-none fs-5"><i class="fas <?= ($row['status'] == 'Selesai') ?
                             'fa-check-circle' : 'fa-circle'; ?>"></i></a>
                            <a href="edit.php?id=<?= $row['id_movie']; ?>" class="text-info text-decoration-none fs-5"><i class="fas fa-edit"></i></a>
                            <a href="javascript:void(0)" onclick="konfirmasiHapus(<?= $row['id_movie']; ?>)" 
                            class="text-danger text-decoration-none fs-5"><i class="fas fa-trash-alt"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
function konfirmasiHapus(id) {
    Swal.fire({
        title: 'Hapus film ini?',
        text: "Data yang dihapus tidak bisa dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e50914',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "hapus.php?id=" + id;
        }
    })
}
</script>

</body>
</html>