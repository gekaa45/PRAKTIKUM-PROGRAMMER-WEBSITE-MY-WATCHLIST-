<?php
$conn = mysqli_connect("localhost", "root", "", "movie_watchlist");
if (!$conn) { die("Koneksi gagal: " . mysqli_connect_error()); }
?>