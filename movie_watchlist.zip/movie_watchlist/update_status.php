<?php
include 'db.php';
$id = $_GET['id'];
$status_sekarang = $_GET['status'];

// Balikkan statusnya
$status_baru = ($status_sekarang == 'Belum') ? 'Selesai' : 'Belum';

mysqli_query($conn, "UPDATE movies SET status = '$status_baru' WHERE id_movie = '$id'");

header("Location: index.php");
?>