<?php 
include 'db.php'; 
require_once 'Media.php'; 
require_once 'MovieLogic.php'; 

use App\MovieLogic;

if(isset($_POST['submit'])){
    // 2. Debugging: Validasi Input Sederhana)
    $judul  = mysqli_real_escape_string($conn, $_POST['judul']);
    $genre  = mysqli_real_escape_string($conn, $_POST['genre']);
    $rating = mysqli_real_escape_string($conn, $_POST['rating']);
    $desc   = mysqli_real_escape_string($conn, $_POST['desc']);
    
    // Proses File Gambar
    $poster = $_FILES['poster']['name'];
    $tmp    = $_FILES['poster']['tmp_name'];
    $path   = "uploads/" . $poster;

    // 3. Simpan Data ke Database
    if(move_uploaded_file($tmp, $path)){
        $query = "INSERT INTO movies (judul_film, genre, rating, poster, deskripsi, status) 
                  VALUES ('$judul', '$genre', '$rating', '$poster', '$desc', 'Belum Ditonton')";
        
        if(mysqli_query($conn, $query)){
            header("Location: index.php?status=success");
        } else {
            echo "Error: " . mysqli_error($conn); // Debugging jika query gagal
        }
    }
}

$movieHelper = new MovieLogic("Tambah Film");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah ke Diary - Movie Watchlist</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#141414; color:white; font-family: 'Inter', sans-serif; }
        .card-custom { background: #1f1f1f; border: 1px solid #333; border-radius: 20px; }
        .form-control:focus { background: #2b2b2b; color: white; border-color: #e50914; box-shadow: none; }
        .btn-save { background: #e50914; color: white; transition: 0.3s; }
        .btn-save:hover { background: #b20710; transform: scale(1.02); }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="card card-custom text-white p-5 mx-auto shadow-lg" style="max-width: 550px;">
        <h3 class="text-center fw-bold mb-4">🎬 Catat Film Baru</h3>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label text-secondary small fw-bold">JUDUL FILM</label>
                <input type="text" name="judul" class="form-control bg-dark text-white border-secondary" placeholder="Contoh: Inception" required>
            </div>
            
            <div class="row mb-3">
                <div class="col">
                    <label class="form-label text-secondary small fw-bold">GENRE</label>
                    <input type="text" name="genre" class="form-control bg-dark text-white border-secondary" placeholder="Action, Sci-Fi">
                </div>
                <div class="col">
                    <label class="form-label text-secondary small fw-bold">RATING (0-10)</label>
                    <input type="number" step="0.1" name="rating" class="form-control bg-dark text-white border-secondary" placeholder="8.5">
                </div>
            </div>
            
            <div class="mb-3">
                <label class="form-label text-secondary small fw-bold">UPLOAD POSTER</label>
                <input type="file" name="poster" class="form-control bg-dark text-white border-secondary" required>
            </div>
            
            <div class="mb-4">
                <label class="form-label text-secondary small fw-bold">MENGAPA INGIN NONTON?</label>
                <textarea name="desc" class="form-control bg-dark text-white border-secondary" rows="3" placeholder="Tuliskan alasan atau sinopsis singkat..."></textarea>
            </div>
            
            <button type="submit" name="submit" class="btn btn-save w-100 fw-bold py-2 mb-3">SIMPAN KE LIST</button>
            <a href="index.php" class="btn btn-link text-secondary w-100 text-decoration-none">Batal dan Kembali</a>
        </form>
        
        <div class="mt-4 pt-3 border-top border-secondary text-center">
            <small class="text-muted">Module: <?= $movieHelper->getJudul(); ?> | <?= $movieHelper->tampilkanWaktu(); ?></small>
        </div>
    </div>
</div>
</body>
</html>