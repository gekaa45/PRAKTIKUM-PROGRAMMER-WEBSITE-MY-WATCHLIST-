<?php 
include 'db.php'; 

// 1. Load logika OOP 
if (file_exists('Media.php') && file_exists('MovieLogic.php')) {
    require_once 'Media.php'; 
    require_once 'MovieLogic.php'; 
    
    // Inisialisasi Class
    $movieHelper = new \App\MovieLogic("Detail View");
    $waktuAkses = $movieHelper->tampilkanWaktu(); 
}

// 2. Debugging & Ambil Data 
$id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : 0;
$query = mysqli_query($conn, "SELECT * FROM movies WHERE id_movie = '$id'");

// Cek apakah data ditemukan
if (mysqli_num_rows($query) == 0) {
    echo "<script>alert('Data tidak ditemukan!'); window.location='index.php';</script>";
    exit;
}

$row = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail - <?= $row['judul_film']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#141414; color:white; font-family: 'Inter', sans-serif; } 
        .poster-big { width:100%; border-radius:15px; box-shadow: 0 0 30px rgba(229,9,20,0.2); }
        .bg-custom { background: #1f1f1f; border: 1px solid #333; }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row align-items-center bg-custom p-5 rounded-4 shadow-lg">
        <div class="col-md-4">
            <img src="uploads/<?= $row['poster']; ?>" class="poster-big" alt="Poster">
        </div>
        <div class="col-md-8">
            <small class="text-secondary">Diakses pada: <?= isset($waktuAkses) ? $waktuAkses : date('d-m-Y H:i'); ?></small>
            <h1 class="display-4 fw-bold mt-2"><?= $row['judul_film']; ?></h1>
            <p class="text-danger fs-4 fw-bold">⭐ <?= $row['rating']; ?> / 10</p>
            <span class="badge bg-danger px-3 py-2 mb-3"><?= $row['genre']; ?></span>
            <hr class="border-secondary">
            <h5 class="text-secondary">Catatan Pribadi:</h5>
            <p class="lead text-light"><?= !empty($row['deskripsi']) ? $row['deskripsi'] : 'Tidak ada deskripsi.'; ?></p>
            
            <div class="mt-5">
                <a href="index.php" class="btn btn-outline-light px-4">Kembali ke Daftar</a>
                <a href="edit.php?id=<?= $row['id_movie']; ?>" class="btn btn-danger px-4 ms-2">Edit Film</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>