<?php
namespace App;

interface Watchable {
    public function tampilkanWaktu();
}

class MovieLogic extends Media implements Watchable {
    public function tampilkanWaktu() {
        return date('d-m-Y H:i'); 
    }
}