<?php
namespace App;

class Media {
    protected $judul;
    public function __construct($judul) {
        $this->judul = $judul;
    }
}