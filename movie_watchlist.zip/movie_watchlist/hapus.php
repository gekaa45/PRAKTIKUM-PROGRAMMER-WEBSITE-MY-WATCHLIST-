<?php 
include 'db.php';
$id = $_GET['id'];
// Hapus foto agar htdocs tidak penuh
$res = mysqli_query($conn, "SELECT poster FROM movies WHERE id_movie='$id'");
$data = mysqli_fetch_assoc($res);
unlink("uploads/".$data['poster']);

mysqli_query($conn, "DELETE FROM movies WHERE id_movie='$id'");
header("Location: index.php");
?>